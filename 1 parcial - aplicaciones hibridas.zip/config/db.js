import { MongoClient } from "mongodb";
import "dotenv/config";

const MONGO_URI = process.env.MONGO_URI;
const DB_NAME = process.env.DB_NAME || "AH20232CP1";

if (!MONGO_URI) {
    throw new Error(
        "Falta la variable de entorno MONGO_URI. Copiá .env.example a .env y completá tu connection string de Atlas."
    );
}

const client = new MongoClient(MONGO_URI);

let db;

export async function connectDB() {
    if (db) return db;
    await client.connect();
    db = client.db(DB_NAME);
    console.log("Conectado a MongoDB:", DB_NAME);
    return db;
}
