import * as clientService from "../services/clientService.js";

export async function getAllClients(req, res) {
  try {
    const clients = await clientService.getAllClients();
    res.json(clients);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function createClient(req, res) {
  try {
    const { name, photo, description } = req.body;

    if (!name || !photo || !description) {
      return res.status(400).json({ error: "name, photo y description son obligatorios" });
    }

    const result = await clientService.createClient({ name, photo, description });
    res.status(201).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
