import * as genreService from "../services/genreService.js";
import { isValidObjectId } from "../utils/validation.js";

export async function getAllGenres(req, res) {
  try {
    const genres = await genreService.getAllGenres();
    res.json(genres);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function getGenreById(req, res) {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const genre = await genreService.getGenreById(req.params.id);
    if (!genre) return res.status(404).json({ error: "Género no encontrado" });
    res.json(genre);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function createGenre(req, res) {
  try {
    const { name, photo, description } = req.body;

    if (!name || !description) {
      return res.status(400).json({ error: "name y description son obligatorios" });
    }

    const genreData = { name, description };
    if (photo) genreData.photo = photo;

    const result = await genreService.createGenre(genreData);
    res.status(201).json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function updateGenre(req, res) {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({ error: "ID inválido" });
    }

    const { name, photo, description } = req.body;
    const genreData = {};
    if (name !== undefined) genreData.name = name;
    if (photo !== undefined) genreData.photo = photo;
    if (description !== undefined) genreData.description = description;

    if (Object.keys(genreData).length === 0) {
      return res.status(400).json({ error: "No se enviaron campos para actualizar" });
    }

    const result = await genreService.updateGenre(req.params.id, genreData);
    if (result.matchedCount === 0) {
      return res.status(404).json({ error: "Género no encontrado" });
    }
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}

export async function deleteGenre(req, res) {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({ error: "ID inválido" });
    }
    const result = await genreService.deleteGenre(req.params.id);
    if (result.deletedCount === 0) {
      return res.status(404).json({ error: "Género no encontrado" });
    }
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
