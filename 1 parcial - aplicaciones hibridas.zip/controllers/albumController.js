import * as albumService from "../services/albumService.js";
import { isValidObjectId } from "../utils/validation.js";

export async function getAllAlbums(req, res) {
    try {
        const filters = {};
        if (req.query.genreId) filters.genreId = req.query.genreId;
        if (req.query.artist) filters.artist = req.query.artist;

        const albums = await albumService.getAllAlbums(filters);
        res.json(albums);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

export async function getAlbumById(req, res) {
    try {
        if (!isValidObjectId(req.params.id)) {
            return res.status(400).json({ error: "ID inválido" });
        }
        const album = await albumService.getAlbumById(req.params.id);
        if (!album) return res.status(404).json({ error: "Álbum no encontrado" });
        res.json(album);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

export async function getAlbumsByGenre(req, res) {
    try {
        if (!isValidObjectId(req.params.genreId)) {
            return res.status(400).json({ error: "genreId inválido" });
        }
        const albums = await albumService.getAlbumsByGenre(req.params.genreId);
        res.json(albums);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

export async function createAlbum(req, res) {
    try {
        const { name, artist, year, link, img, genreId } = req.body;

        if (!name || !artist || !link || !img || !genreId) {
            return res.status(400).json({
                error: "name, artist, link, img y genreId son obligatorios",
            });
        }
        if (!isValidObjectId(genreId)) {
            return res.status(400).json({ error: "genreId inválido" });
        }

        const albumData = { name, artist, link, img, genreId };
        if (year !== undefined) albumData.year = year;

        const result = await albumService.createAlbum(albumData);
        res.status(201).json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

export async function updateAlbum(req, res) {
    try {
        if (!isValidObjectId(req.params.id)) {
            return res.status(400).json({ error: "ID inválido" });
        }

        const { name, artist, year, link, img, genreId } = req.body;

        if (genreId !== undefined && !isValidObjectId(genreId)) {
            return res.status(400).json({ error: "genreId inválido" });
        }

        const albumData = {};
        if (name !== undefined) albumData.name = name;
        if (artist !== undefined) albumData.artist = artist;
        if (year !== undefined) albumData.year = year;
        if (link !== undefined) albumData.link = link;
        if (img !== undefined) albumData.img = img;
        if (genreId !== undefined) albumData.genreId = genreId;

        if (Object.keys(albumData).length === 0) {
            return res.status(400).json({ error: "No se enviaron campos para actualizar" });
        }

        const result = await albumService.updateAlbum(req.params.id, albumData);
        if (result.matchedCount === 0) {
            return res.status(404).json({ error: "Álbum no encontrado" });
        }
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

export async function deleteAlbum(req, res) {
    try {
        if (!isValidObjectId(req.params.id)) {
            return res.status(400).json({ error: "ID inválido" });
        }
        const result = await albumService.deleteAlbum(req.params.id);
        if (result.deletedCount === 0) {
            return res.status(404).json({ error: "Álbum no encontrado" });
        }
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}
