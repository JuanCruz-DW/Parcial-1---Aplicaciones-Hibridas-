import { Router } from "express";
import * as clientController from "../controllers/clientController.js";

const router = Router();

router.get("/", clientController.getAllClients);
router.post("/", clientController.createClient);

export default router;
