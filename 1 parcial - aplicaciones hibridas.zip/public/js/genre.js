const params = new URLSearchParams(window.location.search);
const genreId = params.get("id");

async function loadGenre() {
  const infoDiv = document.getElementById("genre-info");
  const grid = document.getElementById("albums-grid");
  const addLink = document.getElementById("add-album-link");

  if (!genreId) {
    infoDiv.innerHTML = "<p>Falta el id del género en la URL.</p>";
    return;
  }

  addLink.href = "/album-form.html?genreId=" + genreId;

  try {
    const genreRes = await fetch("/api/genres/" + genreId);
    if (!genreRes.ok) {
      infoDiv.innerHTML = "<p>Género no encontrado.</p>";
      return;
    }
    const genre = await genreRes.json();

    infoDiv.innerHTML = `<h1>${genre.name}</h1><p>${genre.description}</p>`;

    const albumsRes = await fetch("/api/albums?genreId=" + genreId);
    const albums = await albumsRes.json();

    if (albums.length === 0) {
      grid.innerHTML = "<p>Todavía no hay álbumes cargados para este género.</p>";
      return;
    }

    grid.innerHTML = albums
      .map(
        (album) => `
        <div class="card">
          <img src="${album.img || ""}" alt="${album.name}" />
          <h3>${album.name}</h3>
          <p>${album.artist}${album.year ? " · " + album.year : ""}</p>
          <a class="btn secondary" href="${album.link}" target="_blank" rel="noopener">Escuchar</a>
          <div class="actions">
            <a class="btn secondary" href="/album-form.html?id=${album._id}">Editar</a>
            <button class="btn danger" onclick="deleteAlbum('${album._id}', '${genreId}')">Eliminar</button>
          </div>
        </div>
      `
      )
      .join("");
  } catch (error) {
    infoDiv.innerHTML = "<p>Error al cargar: " + error.message + "</p>";
  }
}

async function deleteAlbum(id, currentGenreId) {
  if (!confirm("¿Eliminar este álbum?")) return;

  try {
    const res = await fetch("/api/albums/" + id, { method: "DELETE" });
    if (!res.ok) {
      const data = await res.json();
      alert("Error: " + data.error);
      return;
    }
    window.location.href = "/genre.html?id=" + currentGenreId;
  } catch (error) {
    alert("Error al eliminar: " + error.message);
  }
}

loadGenre();
