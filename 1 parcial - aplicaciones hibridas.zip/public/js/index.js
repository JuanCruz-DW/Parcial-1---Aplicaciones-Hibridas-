async function loadGenres() {
  const grid = document.getElementById("genres-grid");

  try {
    const res = await fetch("/api/genres");
    const genres = await res.json();

    if (genres.length === 0) {
      grid.innerHTML = "<p>No hay géneros cargados todavía.</p>";
      return;
    }

    grid.innerHTML = genres
      .map(
        (genre) => `
        <a class="card" href="/genre.html?id=${genre._id}">
          <img src="${genre.photo || ""}" alt="${genre.name}" />
          <h3>${genre.name}</h3>
          <p>${genre.description}</p>
        </a>
      `
      )
      .join("");
  } catch (error) {
    grid.innerHTML = "<p>Error al cargar los géneros: " + error.message + "</p>";
  }
}

loadGenres();
