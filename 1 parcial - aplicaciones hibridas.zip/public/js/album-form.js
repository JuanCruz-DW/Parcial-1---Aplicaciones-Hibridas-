const params = new URLSearchParams(window.location.search);
const albumId = params.get("id");
const preselectedGenreId = params.get("genreId");

const form = document.getElementById("album-form");
const formTitle = document.getElementById("form-title");
const submitBtn = document.getElementById("submit-btn");
const genreSelect = document.getElementById("genreId");

const isEditMode = Boolean(albumId);
let currentGenreId = preselectedGenreId;

async function loadGenresIntoSelect() {
  const res = await fetch("/api/genres");
  const genres = await res.json();

  genreSelect.innerHTML = genres
    .map((g) => `<option value="${g._id}">${g.name}</option>`)
    .join("");
}

async function loadAlbumIfEditing() {
  if (!isEditMode) return;

  formTitle.textContent = "Editar álbum";
  submitBtn.textContent = "Guardar cambios";

  const res = await fetch("/api/albums/" + albumId);
  if (!res.ok) {
    alert("No se encontró el álbum");
    return;
  }
  const album = await res.json();
  currentGenreId = album.genreId;

  document.getElementById("name").value = album.name;
  document.getElementById("artist").value = album.artist;
  document.getElementById("year").value = album.year || "";
  document.getElementById("link").value = album.link;
  document.getElementById("img").value = album.img;
}

async function init() {
  await loadGenresIntoSelect();
  await loadAlbumIfEditing();

  if (currentGenreId) {
    genreSelect.value = currentGenreId;
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const albumData = {
    name: document.getElementById("name").value,
    artist: document.getElementById("artist").value,
    year: document.getElementById("year").value || undefined,
    link: document.getElementById("link").value,
    img: document.getElementById("img").value,
    genreId: genreSelect.value,
  };

  try {
    const url = isEditMode ? "/api/albums/" + albumId : "/api/albums";
    const method = isEditMode ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(albumData),
    });

    if (!res.ok) {
      const data = await res.json();
      alert("Error: " + data.error);
      return;
    }

    window.location.href = "/genre.html?id=" + genreSelect.value;
  } catch (error) {
    alert("Error al guardar: " + error.message);
  }
});

init();
