import express from "express";
import { connectDB } from "./config/db.js";
import genreRoutes from "./routes/genreRoutes.js";
import albumRoutes from "./routes/albumRoutes.js";
import clientRoutes from "./routes/clientRoutes.js";

const app = express();
const PORT = 3333;

// Middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Páginas web (HTML + JS que consumen la API)
app.use(express.static("public"));

// API REST
app.use("/api/genres", genreRoutes);
app.use("/api/albums", albumRoutes);
app.use("/api/clients", clientRoutes);

// Arrancar servidor y conectar DB
async function start() {
    await connectDB();
    app.listen(PORT, () => {
        console.log(`Servidor corriendo en http://localhost:${PORT}`);
    });
}

start();
