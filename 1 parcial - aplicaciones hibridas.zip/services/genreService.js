import { connectDB } from "../config/db.js";
import { ObjectId } from "mongodb";

const COLLECTION = "Genres";

export async function getAllGenres() {
    const db = await connectDB();
    return await db.collection(COLLECTION).find({}).toArray();
}

export async function getGenreById(id) {
    const db = await connectDB();
    return await db.collection(COLLECTION).findOne({ _id: new ObjectId(id) });
}

export async function createGenre(genreData) {
    const db = await connectDB();
    const result = await db.collection(COLLECTION).insertOne(genreData);
    return result;
}

export async function updateGenre(id, genreData) {
    const db = await connectDB();
    const result = await db.collection(COLLECTION).updateOne(
        { _id: new ObjectId(id) },
        { $set: genreData }
    );
    return result;
}

export async function deleteGenre(id) {
    const db = await connectDB();
    const result = await db.collection(COLLECTION).deleteOne({ _id: new ObjectId(id) });
    return result;
}
