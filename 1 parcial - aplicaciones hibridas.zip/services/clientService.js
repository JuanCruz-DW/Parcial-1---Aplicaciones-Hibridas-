import { connectDB } from "../config/db.js";

const COLLECTION = "Clients";

export async function getAllClients() {
    const db = await connectDB();
    return await db.collection(COLLECTION).find({}).toArray();
}

export async function createClient(clientData) {
    const db = await connectDB();
    const result = await db.collection(COLLECTION).insertOne(clientData);
    return result;
}
