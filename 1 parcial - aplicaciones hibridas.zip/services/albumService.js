import { connectDB } from "../config/db.js";
import { ObjectId } from "mongodb";

const COLLECTION = "Albums";

export async function getAllAlbums(filters = {}) {
    const db = await connectDB();

    const query = {};
    if (filters.genreId) query.genreId = filters.genreId;
    if (filters.artist) query.artist = filters.artist;

    return await db.collection(COLLECTION).find(query).toArray();
}

export async function getAlbumById(id) {
    const db = await connectDB();
    return await db.collection(COLLECTION).findOne({ _id: new ObjectId(id) });
}

export async function getAlbumsByGenre(genreId) {
    const db = await connectDB();
    return await db.collection(COLLECTION).find({ genreId }).toArray();
}

export async function createAlbum(albumData) {
    const db = await connectDB();
    const result = await db.collection(COLLECTION).insertOne(albumData);
    return result;
}

export async function updateAlbum(id, albumData) {
    const db = await connectDB();
    const result = await db.collection(COLLECTION).updateOne(
        { _id: new ObjectId(id) },
        { $set: albumData }
    );
    return result;
}

export async function deleteAlbum(id) {
    const db = await connectDB();
    const result = await db.collection(COLLECTION).deleteOne({ _id: new ObjectId(id) });
    return result;
}
